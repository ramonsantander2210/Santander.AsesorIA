# PRD — AsesorIA · Sitio web de Ramón Armando Santander López

**Versión:** 1.2 · **Fecha:** 5 de septiembre de 2026 · *(v1.2: Instagram Santander.AsesorIA · v1.1: datos de contacto y doble reloj de zona horaria)*
**Autor:** Ramón Armando Santander López
**Destino de desarrollo:** Claude Design (artifact HTML de una sola página)
**Estado:** Aprobado para construcción

---

## 📇 Datos de contacto confirmados

| Dato | Valor |
|---|---|
| Correo de contacto | `ramon.santander1@gmail.com` |
| WhatsApp (formato `wa.me`) | `584243063839` |
| WhatsApp (formato visible) | `+58 424 306 3839` |
| Correo de Google Calendar | `ramon.santander1@gmail.com` |
| Zona horaria base | América/Caracas (GMT-4) |
| Idioma | Español LatAm, sin versión en inglés en v1 |
| LinkedIn | `https://www.linkedin.com/in/ram%C3%B3n-armando-santander-l%C3%B3pez-9840991b/` |
| Instagram (URL) | `https://www.instagram.com/santander.asesoria/` |
| Instagram (texto visible) | **Santander.AsesorIA** |

> ⚠️ **Regla de marca:** el handle técnico de Instagram es `santander.asesoria` (minúsculas, sin acento), pero en pantalla **siempre** debe leerse `Santander.AsesorIA`. Nunca mostrar el handle en minúsculas al visitante.

## 🔎 Supuestos que aún faltan por validar

| # | Supuesto | Acción requerida |
|---|---|---|
| S1 | Duración estándar de asesoría: 45 min | Ajustable a 30 / 60 / 90 min. |
| S2 | Los cursos se dictan en modalidad virtual y presencial | Confirmar si aplica solo virtual. |
| S3 | Temario de los cuatro cursos (propuesto en §RF-3) | Validar o sustituir por el real. |
| S4 | Bio personal de 3 a 5 líneas | Pendiente de redactar. |
| S5 | Contenido de los 6 a 9 temas de interés | Pendiente de redactar. |
| S6 | Foto de perfil | Pendiente de aportar. |

---

## 1. Resumen ejecutivo

Página web pública de una sola vista que consolida la oferta de **AsesorIA**, la marca personal de Ramón Santander como asesor y formador en Inteligencia Artificial aplicada al negocio. Sustituye el flujo actual disperso (mensajes sueltos por LinkedIn, correos improvisados, coordinación manual de agenda) por un punto único de entrada.

**Arquitectura clave:** sitio 100% estático, sin servidor ni base de datos. Todas las solicitudes se convierten en **enlaces profundos prellenados** hacia los canales que Ramón ya usa: correo, WhatsApp, LinkedIn y Google Calendar. El visitante llena un formulario en la página, y la página genera el mensaje o el evento listo para enviar por el canal que él prefiera.

**Por qué esta arquitectura:** cero costo de infraestructura, cero mantenimiento, cero riesgo de datos personales almacenados, y publicable de inmediato como artifact de Claude.

---

## 2. Objetivos y métricas

### Objetivo principal
Convertir visitantes de LinkedIn en solicitudes concretas de cursos y asesorías, sin fricción y sin intermediación manual.

### Objetivos específicos

| # | Objetivo | Métrica de éxito |
|---|---|---|
| O1 | Capturar solicitudes de curso estructuradas | El mensaje generado incluye siempre: curso, modalidad, nº participantes, fecha tentativa, datos de contacto |
| O2 | Eliminar el ida y vuelta para agendar | El visitante genera su propio evento de Google Calendar en < 60 segundos |
| O3 | Posicionar autoridad técnica | Sección de temas de interés con contenido propio, no genérico |
| O4 | Canalizar tráfico desde y hacia LinkedIn | Enlace visible al perfil en hero y footer |

### Fuera de alcance (v1)
- Pasarela de pagos o cobro en línea
- Área privada, login o registro de usuarios
- Base de datos, CRM o panel de administración
- Blog con gestor de contenidos (los temas de interés se editan en el código)
- Versión multi-idioma
- Analítica avanzada de comportamiento

---

## 3. Usuario objetivo

**Perfil primario:** profesional o líder de área (gerente, director, jefe de operaciones) que llegó al perfil de LinkedIn de Ramón, quiere formar a su equipo en IA o resolver un problema puntual de automatización, y necesita saber en menos de dos minutos qué se ofrece y cómo contratarlo.

**Perfil secundario:** profesional individual que busca formarse por su cuenta en ingeniería de prompt o herramientas de IA.

**Contexto de uso:** mayoritariamente móvil (tráfico de LinkedIn), en horario laboral, con poca paciencia para formularios largos.

**Implicación de diseño:** mobile-first obligatorio. Formularios de máximo 6 campos. CTA visible sin hacer scroll.

---

## 4. Arquitectura de información

Página única con navegación por anclas y barra superior fija.

```
┌─ HERO
│  Nombre · Propuesta de valor · 2 CTA (Agendar asesoría / Ver cursos)
│  Enlaces a LinkedIn e Instagram
│
├─ SOBRE MÍ
│  Bio breve · Áreas de especialidad · Trayectoria · Redes (LinkedIn + Instagram)
│
├─ CURSOS  (4 tarjetas)
│  Ingeniería de Prompt · Claude AI · Gemini · NotebookLM
│  Cada una: temario, duración, nivel, modalidad, CTA "Solicitar"
│
├─ SOLICITAR CURSO  (formulario → generador de mensaje)
│  Salida: botón Correo · botón WhatsApp · botón LinkedIn · Copiar texto
│
├─ AGENDAR ASESORÍA  (formulario → generador de evento)
│  Salida: botón Google Calendar · QR del evento · botón Correo · botón WhatsApp
│
├─ TEMAS DE INTERÉS SOBRE IA
│  Grid de tarjetas filtrable por etiqueta
│
└─ FOOTER
   Contacto · LinkedIn · Instagram · Aviso de privacidad breve
```

---

## 5. Requerimientos funcionales

### RF-1 · Hero

- Nombre completo y posicionamiento en una frase (máx. 15 palabras).
- Dos botones: **Agendar asesoría** (primario, ancla a §Agendar) y **Ver cursos** (secundario, ancla a §Cursos).
- Fila de redes bajo los botones, con icono SVG en línea y etiqueta de texto:
  - **LinkedIn** → `https://www.linkedin.com/in/ram%C3%B3n-armando-santander-l%C3%B3pez-9840991b/`
    ⚠️ Usar la URL **percent-encoded**, no la versión con acentos.
  - **Santander.AsesorIA** → `https://www.instagram.com/santander.asesoria/`
    ⚠️ El texto visible es `Santander.AsesorIA`, con mayúsculas y la I mayúscula final. El handle en minúsculas solo aparece dentro del `href`.
- Iconos como SVG en línea (no librerías de iconos ni imágenes externas), con `aria-label` descriptivo.
- Todos los enlaces externos: `target="_blank" rel="noopener noreferrer"`.

### RF-2 · Sobre mí

- Bio de 3 a 5 líneas, en primera persona.
- Lista de 4 a 6 áreas de especialidad (ej.: ingeniería de prompt, automatización de procesos, adopción organizacional de IA, análisis de datos).
- Tarjeta con foto de perfil, titular y dos botones: "Conectar en LinkedIn" y "Seguir en Santander.AsesorIA".

### RF-3 · Catálogo de cursos

Cuatro tarjetas con estructura idéntica. Contenido base propuesto (editable):

| Curso | Nivel | Duración | Temario resumido |
|---|---|---|---|
| **Ingeniería de Prompt** | Básico → Avanzado | 8 h (2 sesiones) | Anatomía de un prompt · Framework de 15 elementos · Temperatura y determinismo · Few-shot · Prompts maestros reutilizables · Taller práctico con casos del participante |
| **Claude AI** | Básico → Intermedio | 6 h | Interfaz y proyectos · Artifacts · Skills y automatización · Análisis de archivos · Casos de uso por área · Buenas prácticas y límites |
| **Gemini** | Básico → Intermedio | 4 h | Ecosistema Google · Gemini en Workspace · Multimodalidad · Comparativa con otros modelos · Casos de uso |
| **NotebookLM** | Básico | 3 h | Fuentes y cuadernos · Síntesis de documentos · Resúmenes en audio · Investigación asistida · Aplicación a documentación corporativa |

Cada tarjeta lleva un botón **"Solicitar este curso"** que hace scroll al formulario de §RF-4 y **preselecciona ese curso**.

### RF-4 · Solicitud de curso

**Campos del formulario:**

| Campo | Tipo | Obligatorio |
|---|---|---|
| Nombre y apellido | texto | Sí |
| Empresa u organización | texto | No |
| Correo | email | Sí |
| Curso de interés | select (4 opciones + "Programa a medida") | Sí |
| Modalidad | radio (Virtual / Presencial / Híbrida) | Sí |
| Nº de participantes | número | Sí |
| Fecha tentativa | fecha | No |
| Comentarios | textarea | No |

**Comportamiento:**

1. Validación en cliente. Mensajes de error específicos junto a cada campo, nunca un alert genérico.
2. Al pulsar **"Generar solicitud"**, la página compone un mensaje de texto plano estructurado y lo muestra en un panel de resultado.
3. El panel ofrece cuatro acciones:
   - **Enviar por correo** → `mailto:ramon.santander1@gmail.com` con asunto y cuerpo prellenados
   - **Enviar por WhatsApp** → `https://wa.me/584243063839?text=<mensaje>`
   - **Enviar por LinkedIn** → abre el perfil en pestaña nueva y copia el mensaje al portapapeles, con aviso: *"Mensaje copiado. Pégalo en el chat de LinkedIn."*
   - **Copiar texto** → portapapeles, con confirmación visual
4. Ningún dato se almacena ni se envía a servidor alguno. Debe indicarse explícitamente bajo el formulario.

**Plantilla del mensaje generado:**

```
Solicitud de curso — AsesorIA

Curso: {curso}
Modalidad: {modalidad}
Participantes: {n}
Fecha tentativa: {fecha o "por definir"}

Solicitante: {nombre}
Organización: {empresa o "—"}
Correo: {correo}

Comentarios: {comentarios o "—"}
```

### RF-5 · Agendar asesoría

**Campos:**

| Campo | Tipo | Obligatorio |
|---|---|---|
| Nombre y apellido | texto | Sí |
| Correo | email | Sí |
| Tema de la asesoría | select (Ingeniería de prompt · Automatización de procesos · Adopción de IA en el equipo · Otro) | Sí |
| Fecha | date | Sí |
| Hora | time | Sí |
| Duración | select (30 / 45 / 60 / 90 min) — default 45 | Sí |
| Notas | textarea | No |

**Comportamiento:**

1. Al pulsar **"Generar cita"**, la página construye una URL de Google Calendar en formato plantilla:

```
https://calendar.google.com/calendar/render
  ?action=TEMPLATE
  &text=Asesoría IA — {nombre}
  &dates={inicioUTC}/{finUTC}
  &details={tema, notas, correo del solicitante}
  &add=ramon.santander1@gmail.com
```

   Formato de fechas: `YYYYMMDDTHHMMSSZ` en UTC. El fin se calcula sumando la duración al inicio. La conversión de hora local a UTC debe usar la zona del navegador del visitante.

   **Doble reloj obligatorio.** Junto al campo de hora, la página muestra siempre dos referencias: la hora local del visitante y su equivalente en **Caracas (GMT-4)**, que es la zona de trabajo de Ramón. Ejemplo: *"14:00 en tu zona horaria · 13:00 en Caracas (GMT-4)"*. Esto evita citas agendadas a horas imposibles, que es el error más común cuando el público es internacional.

2. Se muestran tres salidas:
   - Botón **"Agregar a Google Calendar"** (abre la URL)
   - **Código QR** que codifica esa misma URL, para escanear desde el móvil
   - Botones de **correo** y **WhatsApp** con el detalle de la cita y el enlace incluidos

3. Validaciones: no permitir fechas pasadas; advertir (sin bloquear) si la hora **en Caracas** cae fuera del rango 8:00–18:00, con el mensaje *"Esa hora queda fuera de mi horario habitual en Caracas. Puedes agendarla igual y la confirmo o te propongo otra."*

4. Aviso visible: *"Este enlace crea el evento en tu calendario y me envía la invitación. Te confirmo por el mismo canal en menos de 24 horas hábiles."*

### RF-6 · Temas de interés sobre IA

- Grid responsivo de tarjetas (3 columnas en escritorio, 1 en móvil).
- Cada tarjeta: etiqueta, título, resumen de 2 a 3 líneas, y — si aplica — enlace a la publicación en LinkedIn.
- Filtro por etiqueta mediante chips: `Prompt Engineering`, `Automatización`, `Adopción`, `Herramientas`, `Casos de uso`.
- Contenido inicial: 6 a 9 temas, redactados por Ramón. **No usar texto de relleno.**
- Nota al pie: *"Publico sobre estos temas en LinkedIn y en Santander.AsesorIA"* + ambos enlaces.

### RF-7 · Footer

- Correo, WhatsApp, LinkedIn e Instagram (**Santander.AsesorIA**) como enlaces directos.
- Línea de privacidad: *"Este sitio no almacena datos. Los formularios generan mensajes que tú decides enviar."*
- Año y nombre.

---

## 6. Requerimientos no funcionales

| # | Requerimiento | Criterio verificable |
|---|---|---|
| RNF-1 | Archivo único autocontenido | Todo el CSS y JS en línea. Sin peticiones de red salvo la librería de QR. |
| RNF-2 | Responsive | Sin scroll horizontal entre 320 px y 1920 px. Probado en 375 px y 1440 px. |
| RNF-3 | Tema claro y oscuro | Tokens CSS en `:root`; redefinición bajo `@media (prefers-color-scheme: dark)` y `[data-theme]`. Fondo del body siempre explícito. |
| RNF-4 | Accesibilidad | Contraste AA mínimo · navegable por teclado · `label` en todo input · foco visible · `aria-live` en los paneles de resultado. |
| RNF-5 | Rendimiento | Renderiza en < 1 s. Sin imágenes pesadas; foto de perfil optimizada e incrustada como data URI. |
| RNF-6 | Privacidad | Cero almacenamiento de datos personales. `localStorage` solo para la preferencia de tema, envuelto en `try/catch`. |
| RNF-7 | Compatibilidad | Chrome, Edge, Safari y Firefox en versiones actuales. |

---

## 7. Notas técnicas para Claude Design

### Librería de QR
Única dependencia externa permitida. Cargar desde el CDN admitido:

```html
<script src="https://cdnjs.cloudflare.com/ajax/libs/qrcodejs/1.0.0/qrcode.min.js"></script>
```

Debe ir **antes** del script en línea que la usa. Si la librería no carga, el bloque de QR se oculta y el resto de la página sigue funcionando.

### Codificación de enlaces
Todo parámetro de URL pasa por `encodeURIComponent()`. Los saltos de línea en `mailto:` se codifican como `%0D%0A`; en `wa.me` como `%0A`.

### Estructura del archivo
Claude Design envuelve el contenido en el esqueleto HTML al publicar. El archivo debe empezar directamente con `<title>` y `<style>`, **sin** `<!DOCTYPE>`, `<html>`, `<head>` ni `<body>`.

### Paleta sugerida (marca personal AsesorIA)
Sobria y profesional, distinta de la identidad corporativa de Farmatodo:

- Tinta / texto principal: `#0F172A`
- Acento primario: `#2563EB`
- Acento secundario: `#0EA5E9`
- Fondo claro: `#FAFAF9`
- Superficie: `#FFFFFF`
- Texto secundario: `#475569`
- Tipografías: Inter o system-ui para cuerpo; peso 600–700 para titulares.

---

## 8. Criterios de aceptación

La v1 se considera terminada cuando:

1. Las cuatro funciones (cursos, agenda, LinkedIn, temas) operan desde una sola página publicada.
2. Un visitante en móvil completa una solicitud de curso y llega a WhatsApp con el mensaje prellenado, sin errores.
3. El enlace de Google Calendar generado abre un evento con título, fecha, hora, duración e invitado correctos.
4. El QR escaneado desde un teléfono abre ese mismo evento.
5. La página se ve correcta en tema claro y oscuro, a 375 px y a 1440 px.
6. Ninguna sección contiene texto de relleno ni datos ficticios.
7. No hay errores en la consola del navegador.
8. La cadena `santander.asesoria` en minúsculas aparece únicamente dentro de atributos `href`; todo texto visible dice **Santander.AsesorIA**.

---

## 9. Roadmap posterior

| Versión | Alcance |
|---|---|
| **v1.1** | Página de agradecimiento tras generar la solicitud · testimonios · sección de preguntas frecuentes |
| **v1.2** | Migrar la agenda a Calendly o Google Appointment Schedules con disponibilidad real |
| **v2.0** | Panel privado con base de datos del artifact para ver y gestionar solicitudes · analítica de conversión · versión en inglés |

---

# 📋 PROMPT MAESTRO — Construcción del sitio AsesorIA en Claude Design

**Framework de 15 Elementos · Temperatura sugerida: 0.3**

> ⚠️ **ANTES DE PEGAR:** adjunta este PRD y tu foto de perfil. Los datos de contacto ya están incorporados en el prompt; falta que aportes bio, temarios y temas de interés cuando Claude te los pida.

```
──────────────────────────────────────────
BLOQUE A — IDENTIDAD Y CONTEXTO
──────────────────────────────────────────

1. ROL
Actúa como Diseñador de Producto Digital y Desarrollador Frontend Senior con
más de 15 años construyendo landing pages de alta conversión para marcas
personales de consultores y formadores. Dominas HTML semántico, CSS moderno
(custom properties, grid, flexbox), JavaScript vanilla, diseño responsive
mobile-first y accesibilidad WCAG 2.1 nivel AA. Tienes criterio editorial:
sabes qué texto sobra y qué jerarquía visual hace que un visitante actúe.

2. CONTEXTO
Construyes el sitio web público de AsesorIA, la marca personal de Ramón
Armando Santander López como asesor y formador en Inteligencia Artificial.
La audiencia es externa: profesionales y líderes de área que llegan desde
LinkedIn, mayoritariamente desde el móvil, en horario laboral y con poco
tiempo. El sitio se publica como artifact de Claude y su URL se comparte
desde el perfil de LinkedIn. No es un sitio corporativo de Farmatodo y no
debe llevar ninguna referencia, logo ni paleta de esa empresa.

3. OBJETIVO
Construir una página web de una sola vista, autocontenida y publicable, que:
(a) presente el catálogo de cuatro cursos con temario y CTA individual;
(b) capture solicitudes de curso mediante un formulario que genere un mensaje
    estructurado y lo canalice a correo, WhatsApp o LinkedIn;
(c) permita agendar asesorías generando un enlace de Google Calendar y su
    código QR;
(d) exhiba temas de interés sobre IA en un grid filtrable por etiqueta;
(e) enlace de forma visible al perfil de LinkedIn y a la cuenta de Instagram
    Santander.AsesorIA, en hero, sobre mí y footer.

4. INSUMOS
Trabaja ÚNICAMENTE con el PRD adjunto y con los datos que Ramón proporcione
en este chat. No inventes credenciales, testimonios, cifras de alumnos, logos
de clientes ni ningún dato que no haya sido entregado.

Datos de contacto confirmados — úsalos exactamente así:
- Correo:            ramon.santander1@gmail.com
- WhatsApp (wa.me):  584243063839
- WhatsApp visible:  +58 424 306 3839
- Google Calendar:   ramon.santander1@gmail.com
- Zona horaria base: América/Caracas (GMT-4)
- Idioma:            español LatAm
- LinkedIn:          https://www.linkedin.com/in/ram%C3%B3n-armando-santander-l%C3%B3pez-9840991b/
- Instagram (href):  https://www.instagram.com/santander.asesoria/
- Instagram (texto): Santander.AsesorIA

REGLA DE MARCA INNEGOCIABLE: el handle de Instagram se escribe en minúsculas
y sin acento SOLO dentro del atributo href. En todo texto visible para el
visitante —hero, sobre mí, temas de interés, footer, aria-label, title— debe
leerse exactamente "Santander.AsesorIA", con S mayúscula, A mayúscula e I
mayúscula final. Nunca "santander.asesoria", "Santander.Asesoria" ni
"@santander.asesoria" en pantalla.

Datos que Ramón aún debe entregarte y debes pedirle antes de codificar:
bio de 3 a 5 líneas, foto de perfil, temario real de los cuatro cursos y el
contenido de los 6 a 9 temas de interés.

──────────────────────────────────────────
BLOQUE B — LÍMITES Y ESTRUCTURA
──────────────────────────────────────────

5. ALCANCE
Versión 1 únicamente: las siete secciones definidas en el PRD (hero, sobre mí,
cursos, solicitud de curso, agendar asesoría, temas de interés, footer).
Quedan fuera: pagos, login, base de datos, panel de administración, blog con
gestor de contenidos, multi-idioma y analítica.

6. RESTRICCIONES
- NO uses backend, base de datos ni almacenamiento de datos personales.
- NO uses frameworks ni build tools: HTML, CSS y JavaScript vanilla en línea.
- NO cargues recursos externos salvo la librería de QR desde
  https://cdnjs.cloudflare.com (versión fijada explícitamente).
- NO escribas texto de relleno tipo Lorem ipsum ni contenido genérico de
  plantilla: si falta contenido real, deja un marcador visible y pregúntalo.
- NO alteres los datos de contacto del elemento 4: cópialos literalmente.
- NO incluyas <!DOCTYPE>, <html>, <head> ni <body>: el archivo empieza en
  <title> y <style>.
- NO uses la paleta ni la tipografía corporativa de Farmatodo.
- NO definas ningún color únicamente dentro de un bloque @media o [data-theme].

7. ESTRUCTURA DE SALIDA
Un solo archivo HTML con este orden: <title> · <style> con tokens y estilos ·
<script> del CDN de QR · marcado semántico de las siete secciones en el orden
del PRD · <script> en línea con toda la lógica.
Acompaña la entrega con una nota breve (máx. 10 líneas) que liste: qué quedó
construido, qué marcadores faltan por llenar y qué probar primero.

8. FORMATO
Mobile-first. Ancho máximo de contenido 1120 px, centrado. Secciones con
respiración generosa (mín. 80 px de separación vertical en escritorio).
Tarjetas de curso en grid de 2 columnas en escritorio y 1 en móvil.
Temas de interés en grid de 3 / 2 / 1 columnas.
Formularios de una sola columna, máximo 6 campos visibles a la vez.
Paneles de resultado con fondo diferenciado y borde de acento.
Tema claro y oscuro mediante tokens CSS en :root, redefinidos bajo
@media (prefers-color-scheme: dark) con guarda :root:not([data-theme="light"])
y bajo :root[data-theme="dark"].

──────────────────────────────────────────
BLOQUE C — ESTILO Y PROFUNDIDAD
──────────────────────────────────────────

9. TONO
Del texto de la página: profesional, directo y en primera persona. Cercano sin
ser informal. Sin superlativos vacíos ("líder mundial", "revolucionario"), sin
jerga de marketing, sin emojis decorativos. Frases cortas. El visitante debe
entender qué se ofrece y qué hacer a continuación, sin releer.
Del diseño: sobrio, técnico y confiable. Tipografía clara, mucho blanco,
acento cromático usado con parquedad y solo en elementos accionables.

10. NIVEL DE PROFUNDIDAD
Código de calidad de producción, listo para publicar sin edición posterior:
comentado en las secciones de lógica no obvia (construcción de URLs, cálculo
de fechas UTC, generación del QR), con manejo de errores en cada punto de
fallo posible, y con validación de formularios que dé mensajes específicos
por campo. Nada de prototipos ni pseudocódigo.

──────────────────────────────────────────
BLOQUE D — CONTROL DE CALIDAD
──────────────────────────────────────────

11. REGLAS DE CALIDAD
- Todo parámetro de URL pasa por encodeURIComponent().
- Saltos de línea: %0D%0A en mailto, %0A en wa.me.
- Fechas de Google Calendar en formato YYYYMMDDTHHMMSSZ (UTC), calculadas
  desde la zona horaria del navegador del visitante.
- Doble reloj junto al campo de hora: hora local del visitante y su
  equivalente en Caracas (GMT-4), ambas visibles antes de generar el enlace.
- Toda lectura o escritura en localStorage envuelta en try/catch, con la
  página renderizando correctamente si no hay valor guardado.
- Si la librería de QR no carga, ocultar ese bloque sin romper la página.
- Cada input con su <label> asociado; paneles de resultado con aria-live.
- Contraste mínimo AA en ambos temas; foco de teclado siempre visible.
- Cero errores y cero advertencias en la consola del navegador.
- Enlaces externos con target="_blank" rel="noopener noreferrer".
- Iconos de redes como SVG en línea, nunca como librería externa ni imagen
  remota, cada uno con aria-label descriptivo.
- Antes de entregar, busca en todo el archivo la cadena "santander.asesoria"
  y verifica que solo aparezca dentro de un href. Cualquier aparición en
  texto visible es un defecto que debes corregir.

12. MANEJO DE AMBIGÜEDAD
Si falta un dato esencial (número de WhatsApp, correo de contacto, bio,
contenido real de los temas de interés), NO lo inventes ni uses un ejemplo
plausible: inserta un marcador visible del tipo [PENDIENTE: número de
WhatsApp] y enuméralo en la nota de entrega. Si una decisión de diseño admite
varias opciones razonables y afecta la experiencia, elige la más conservadora,
señálala como [Requiere validación] y explica en una línea por qué.

13. MODO DE RAZONAMIENTO
Trabaja en este orden, sin saltarte pasos:
(1) Relee el PRD y lista los datos que faltan; pregúntalos antes de codificar.
(2) Define el sistema de tokens: color, tipografía, espaciado, radios, sombras.
(3) Escribe el marcado semántico completo de las siete secciones.
(4) Aplica los estilos, empezando por móvil y ampliando con media queries.
(5) Implementa la lógica: validación, generación de mensajes, construcción de
    URLs, cálculo de fechas UTC, QR, portapapeles, cambio de tema.
(6) Repasa contra la lista de criterios de aceptación del PRD y corrige.
(7) Publica y redacta la nota de entrega.

──────────────────────────────────────────
BLOQUE E — CIERRE Y EJECUCIÓN
──────────────────────────────────────────

14. CRITERIO DE ÉXITO
La página está terminada cuando cumple los ocho criterios de aceptación del
PRD: las cuatro funciones operan en una sola vista; una solicitud de curso
desde móvil llega a WhatsApp con el mensaje prellenado; el enlace de Google
Calendar abre un evento con título, fecha, hora, duración e invitado
correctos; el QR abre ese mismo evento; se ve bien en claro y oscuro a 375 px
y 1440 px; no hay texto de relleno; la consola está limpia; y el nombre de
Instagram se lee "Santander.AsesorIA" en todo texto visible.
Ramón debe poder compartir la URL desde su perfil de LinkedIn el mismo día,
sin retocar nada.

15. INSTRUCCIÓN FINAL
Ejecuta respetando todas las instrucciones anteriores. Antes de escribir una
sola línea de código, pregunta por los datos marcados como pendientes en el
PRD. Cuando los tengas, construye la página completa, publícala como artifact
y entrega la nota de cierre. Comienza ahora.
```

---

## ✅ Verificación de completitud del Prompt Maestro

```
[x] 1 Rol          [x] 6 Restricciones       [x] 11 Reglas de calidad
[x] 2 Contexto     [x] 7 Estructura salida   [x] 12 Manejo ambigüedad
[x] 3 Objetivo     [x] 8 Formato             [x] 13 Modo razonamiento
[x] 4 Insumos      [x] 9 Tono                [x] 14 Criterio de éxito
[x] 5 Alcance      [x] 10 Profundidad        [x] 15 Instrucción final
```

Los 15 elementos están redactados de forma específica y accionable. Ninguno quedó como marcador ni como `[NO APLICA]`.

---

# 🪜 Paso a paso para ejecutarlo en Claude Design

### Paso 0 · Reúne el contenido que falta (30 minutos, antes de abrir Claude)

Los datos de contacto ya están en el PRD. Lo que falta es contenido tuyo, y es la causa número uno de tener que rehacer el trabajo:

- Tu bio en 3 a 5 líneas, escrita en primera persona
- Tu foto de perfil en JPG o PNG, cuadrada y menor a 500 KB
- Temario real de cada uno de los cuatro cursos, o valida el propuesto en §RF-3
- Los 6 a 9 temas de interés: etiqueta, título y resumen de 2 a 3 líneas cada uno

### Paso 1 · Valida los supuestos pendientes

Recorre la tabla S1 a S6 y corrige lo que no aplique. Un supuesto equivocado que sobrevive al PRD termina en el producto.

### Paso 2 · Abre una conversación nueva en Claude

Empieza limpio, sin contexto arrastrado de otras conversaciones.

### Paso 3 · Adjunta y pega

1. Adjunta este PRD (`PRD-AsesorIA-Web.md`) y tu foto de perfil.
2. Pega el Prompt Maestro completo, desde `1. ROL` hasta `Comienza ahora`.
3. Debajo del prompt, agrega el contenido del Paso 0 en un bloque claro: bio, temarios y temas de interés.

### Paso 4 · Responde las preguntas antes de que construya

El prompt instruye a Claude a preguntar por lo que falte antes de codificar. Respóndele con precisión. Este intercambio de dos minutos ahorra tres rondas de correcciones.

### Paso 5 · Revisa el primer entregable con la lista de aceptación

Abre la página publicada y recorre los siete criterios de §8, uno por uno. Prueba en particular:

- Generar una solicitud de curso y abrir el enlace de WhatsApp
- Generar una cita y abrir el enlace de Google Calendar: verifica título, fecha, hora, y que `ramon.santander1@gmail.com` aparezca como invitado
- El doble reloj: cambia la zona horaria de tu equipo y comprueba que la equivalencia en Caracas se recalcula bien
- Escanear el QR con tu propio teléfono
- Cambiar entre tema claro y oscuro
- Abrir la página en el móvil
- Buscar `santander.asesoria` en la página con Ctrl+F: no debe encontrarse ninguna coincidencia en texto visible

### Paso 6 · Itera con correcciones concretas

Pide cambios específicos, no generales. *"El botón de WhatsApp no incluye el número de participantes en el mensaje"* funciona; *"mejóralo"* no. Claude Design republica sobre la misma URL, así que el enlace que compartas no cambia.

### Paso 7 · Publica y difunde

1. Copia la URL del artifact.
2. Agrégala a tu perfil de LinkedIn en el campo de sitio web y en la sección Destacado.
3. Ponla en la bio de Instagram de **Santander.AsesorIA** como enlace único.
4. Publica un post en ambas redes anunciando el sitio y enlázalo.

### Paso 8 · Mide y ajusta

Al mes, revisa cuántas solicitudes te llegaron por cada canal. Si WhatsApp domina, sube ese botón a la posición principal. Si el calendario no se usa, revisa si el flujo de agendar es claro o si conviene pasar a Calendly (roadmap v1.2).

---

*Documento generado con el Framework de 15 Elementos · AsesorIA · Ramón Armando Santander López*
